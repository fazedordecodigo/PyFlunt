"""Module Notification."""


class Notification:
    """Class Notification."""

    def __init__(self, key: str, message: str) -> None:
        """Found 'Constructor'."""
        self.key: str = key
        self.message: str = message
